from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector
from datetime import datetime
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = app.config['SECRET_KEY']

def get_db_connection():
    return mysql.connector.connect(
        host=app.config['MYSQL_HOST'],
        user=app.config['MYSQL_USER'],
        password=app.config['MYSQL_PASSWORD'],
        database=app.config['MYSQL_DB']
    )

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página.', 'danger')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM vehiculos')
    vehicles = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', vehicles=vehicles)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute('SELECT idUsuario, nomUsuario AS nombre, idRol FROM usuarios WHERE Correo = %s AND Contraseña = %s', (email, password))
        user = cursor.fetchone()

        if user:
            session['user_id'] = user['idUsuario']
            session['user_name'] = user['nombre']
            flash(f'Bienvenido, {user["nombre"]}', 'success')

            if user['idRol'] == 1:
                cursor.close()
                conn.close()
                return redirect(url_for('vendedor_dashboard'))
            elif user['idRol'] == 2:
                cursor.execute('SELECT * FROM vehiculos')
                vehicles = cursor.fetchall()
                cursor.close()
                conn.close()
                return render_template('cliente/vehiculos.html', vehicles=vehicles)

        flash('Correo o contraseña incorrectos', 'danger')
        cursor.close()
        conn.close()
    
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nombre = request.form['nombre']
        email = request.form['email']
        password = request.form['password']
        direccion = request.form['direccion']
        ciudad = request.form['ciudad']
        telefono = request.form['telefono']
        idRol = 2  # Asigna el idRol deseado (en este caso, 2)

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            # Insertar usuario en la tabla `usuarios`
            cursor.execute('INSERT INTO usuarios (Correo, Contraseña, nomUsuario, idRol) VALUES (%s, %s, %s, %s)',
                           (email, password, nombre, idRol))
            conn.commit()

            # Obtener el ID del usuario recién creado
            user_id = cursor.lastrowid
            print(f'User ID: {user_id}')  # Debug: print user_id

            # Verificar si el ID de usuario se obtuvo correctamente
            if user_id:
                print(f'Inserting into clientes with idCliente={user_id}, nombre={nombre}, direccion={direccion}, ciudad={ciudad}, telefono={telefono}, idRol={idRol}')  # Debug
                # Insertar cliente en la tabla `clientes`
                cursor.execute('INSERT INTO clientes (idCliente, nombre, direccion, ciudad, telefono, idRol) VALUES (%s, %s, %s, %s, %s, %s)',
                               (user_id, nombre, direccion, ciudad, telefono, idRol))
                conn.commit()
                flash('Registro exitoso como usuario. Por favor inicia sesión.', 'success')
                return redirect(url_for('login'))
            else:
                flash('Error al obtener el ID del usuario.', 'error')
                conn.rollback()

        except mysql.connector.Error as err:
            flash(f'Error al registrar: {err}', 'error')
            conn.rollback()

        finally:
            cursor.close()
            conn.close()

    return render_template('register.html')



@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('Has cerrado sesión correctamente.', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def vendedor_dashboard():
    if 'user_id' in session and session['user_id']:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM vehiculos')
        vehicles = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template('vendedor_dashboard.html', vehicles=vehicles)
    else:
        flash('Debes iniciar sesión primero.', 'danger')
        return redirect(url_for('login'))

@app.route('/agregar_vehiculo')
@login_required
def agregar_vehiculo():
    return render_template('agregar_vehiculo.html')

@app.route('/guardar_vehiculo', methods=['POST'])
@login_required
def guardar_vehiculo():
    if request.method == 'POST':
        marca = request.form['marca']
        modelo = request.form['modelo']
        color = request.form['color']
        precio = request.form['precio']
        matricula = request.form['matricula']
        imagen = request.form['imagen']

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute('INSERT INTO vehiculos (marca, modelo, color, precio, matricula, imagen) VALUES (%s, %s, %s, %s, %s, %s)',
                           (marca, modelo, color, precio, matricula, imagen))
            conn.commit()
            flash('Vehículo agregado correctamente.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error al agregar vehículo: {err}', 'error')
            conn.rollback()
        finally:
            cursor.close()
            conn.close()

    return redirect(url_for('vendedor_dashboard'))

@app.route('/editar_vehiculo/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_vehiculo(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        marca = request.form['marca']
        modelo = request.form['modelo']
        color = request.form['color']
        precio = request.form['precio']
        matricula = request.form['matricula']
        imagen = request.form['imagen']

        try:
            cursor.execute('UPDATE vehiculos SET marca = %s, modelo = %s, color = %s, precio = %s, matricula = %s, imagen = %s WHERE idVehiculo = %s',
                           (marca, modelo, color, precio, matricula, imagen, id))
            conn.commit()
            flash('Vehículo actualizado correctamente.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error al actualizar vehículo: {err}', 'error')
            conn.rollback()
        finally:
            cursor.close()
            conn.close()
            return redirect(url_for('vendedor_dashboard'))

    cursor.execute('SELECT * FROM vehiculos WHERE idVehiculo = %s', (id,))
    vehicle = cursor.fetchone()
    cursor.close()
    conn.close()

    return render_template('editar_vehiculo.html', vehicle=vehicle)


@app.route('/eliminar_vehiculo/<int:id>', methods=['GET', 'POST'])
@login_required
def eliminar_vehiculo(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        try:
            cursor.execute('DELETE FROM vehiculos WHERE idVehiculo = %s', (id,))
            conn.commit()
            flash('Vehículo eliminado correctamente.', 'success')
        except mysql.connector.Error as err:
            flash(f'Error al eliminar vehículo: {err}', 'error')
            conn.rollback()
        finally:
            cursor.close()
            conn.close()
            return redirect(url_for('vendedor_dashboard'))

    cursor.execute('SELECT * FROM vehiculos WHERE idVehiculo = %s', (id,))
    vehicle = cursor.fetchone()
    cursor.close()
    conn.close()

    return render_template('eliminar_vehiculo.html', vehicle=vehicle)

@app.route('/Vehicule')
def vehiculos():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM vehiculos')
    vehicles = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('cliente/vehiculos.html', vehicles=vehicles)

@app.route('/ventas')
@login_required
def ventas():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT v.idVenta, v.idVehiculo, v.fechaVenta, vh.precio, c.nombre \
                    FROM ventas v \
                    INNER JOIN clientes c ON v.idCliente = c.idCliente\
                    INNER JOIN vehiculos vh ON v.idVehiculo = vh.idVehiculo')
    ventas = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('ventas.html', ventas=ventas)

@app.route('/sale', methods=['GET', 'POST'])
@login_required
def sale():
    if request.method == 'POST':
        idCliente = session.get('user_id')
        if idCliente is None:
            flash('Error: No se ha encontrado el ID del cliente en la sesión.', 'error')
            return redirect(url_for('vehiculos'))

        idVehiculo = request.form['idVehiculo']
        fecha_compra = request.form['fecha_compra']

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            # Verificar si el idVehiculo existe en la tabla vehiculos
            cursor.execute('SELECT idVehiculo FROM vehiculos WHERE idVehiculo = %s', (idVehiculo,))
            vehiculo_existente = cursor.fetchone()

            if vehiculo_existente:
                cursor.execute('INSERT INTO ventas (idCliente, idVehiculo, fechaVenta) VALUES (%s, %s, %s)',
                               (idCliente, idVehiculo, fecha_compra))
                conn.commit()
                flash('Venta registrada correctamente.', 'success')
            else:
                flash('Error: El vehículo seleccionado no existe.', 'error')
                conn.rollback()

        except Exception as e:
            flash(f'Error al registrar la venta: {str(e)}', 'error')
            conn.rollback()

        finally:
            cursor.close()
            conn.close()
            return redirect(url_for('vehiculos'))  # Redirigir a la página de vehículos

    # Si es un GET, obtener todos los vehículos disponibles para mostrar en el formulario
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT idVehiculo, marca, modelo FROM vehiculos')
    vehiculos = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('sale.html', vehiculos=vehiculos)


if __name__ == '__main__':
    app.run(debug=True, port=4000)

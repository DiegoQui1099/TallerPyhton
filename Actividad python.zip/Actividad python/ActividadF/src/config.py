import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'jeje'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'bdtaller'
    MYSQL_CURSORCLASS = 'DictCursor'
